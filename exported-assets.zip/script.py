
# Создаю полный код бота с ПОЛНЫМ функционалом для скачивания
import os

# Полный код бота
bot_code = """import telebot
from telebot import types
import sqlite3
import schedule
import time
import threading
from datetime import datetime, timedelta, date
import json
import re
import os

# Получаем токен из переменных окружения (для безопасности на хостинге)
BOT_TOKEN = os.environ.get("BOT_TOKEN", "7960648611:AAG_eOK7wr6udWzRYO7FAOp2bERSKUBFa6A")
bot = telebot.TeleBot(BOT_TOKEN)

# Глобальный словарь для состояний пользователей
user_states = {}

class UserState:
    IDLE = "idle"
    ADDING_TASK = "adding_task"
    ADDING_RECURRING_TASK = "adding_recurring_task"
    UPLOADING_SCHEDULE = "uploading_schedule"
    SELECTING_DATE = "selecting_date"

def init_db():
    '''Инициализация базы данных'''
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            timezone_offset INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            task_text TEXT NOT NULL,
            task_date DATE NOT NULL,
            task_time TIME,
            priority INTEGER DEFAULT 1,
            category TEXT DEFAULT 'Общее',
            is_completed BOOLEAN DEFAULT FALSE,
            completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS recurring_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            task_text TEXT NOT NULL,
            recurrence_type TEXT NOT NULL,
            days_of_week TEXT,
            day_of_month INTEGER,
            task_time TIME,
            priority INTEGER DEFAULT 1,
            category TEXT DEFAULT 'Общее',
            is_active BOOLEAN DEFAULT TRUE,
            last_generated DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')
    
    conn.commit()
    conn.close()

def add_user(user_id, username, first_name):
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR IGNORE INTO users (user_id, username, first_name)
        VALUES (?, ?, ?)
    ''', (user_id, username, first_name))
    conn.commit()
    conn.close()

def get_daily_tasks(user_id, date_str):
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, task_text, task_time, is_completed, priority, category
        FROM tasks 
        WHERE user_id = ? AND task_date = ?
        ORDER BY priority DESC, task_time, created_at
    ''', (user_id, date_str))
    tasks = cursor.fetchall()
    conn.close()
    return tasks

def add_task(user_id, task_text, task_date, task_time=None, priority=1, category='Общее'):
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO tasks (user_id, task_text, task_date, task_time, priority, category)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (user_id, task_text, task_date, task_time, priority, category))
    conn.commit()
    conn.close()

def toggle_task_completion(task_id, user_id):
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    
    cursor.execute('SELECT is_completed FROM tasks WHERE id = ? AND user_id = ?', (task_id, user_id))
    result = cursor.fetchone()
    
    if result:
        new_status = not result[0]
        completed_at = datetime.now().isoformat() if new_status else None
        cursor.execute('''
            UPDATE tasks 
            SET is_completed = ?, completed_at = ?
            WHERE id = ? AND user_id = ?
        ''', (new_status, completed_at, task_id, user_id))
        conn.commit()
        conn.close()
        return new_status
    
    conn.close()
    return None

def get_user_stats(user_id, days=7):
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days-1)
    
    cursor.execute('''
        SELECT 
            COUNT(*) as total_tasks,
            SUM(CASE WHEN is_completed = 1 THEN 1 ELSE 0 END) as completed_tasks
        FROM tasks 
        WHERE user_id = ? AND task_date >= ? AND task_date <= ?
    ''', (user_id, start_date.isoformat(), end_date.isoformat()))
    
    stats = cursor.fetchone()
    conn.close()
    
    total, completed = stats if stats else (0, 0)
    return {
        'total': total,
        'completed': completed,
        'percentage': (completed / total * 100) if total > 0 else 0
    }

def generate_recurring_tasks():
    '''Генерирует повторяющиеся задачи на сегодня'''
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    
    today = datetime.now().date()
    today_weekday = today.weekday()
    
    cursor.execute('''
        SELECT id, user_id, task_text, recurrence_type, task_time, days_of_week, day_of_month, last_generated
        FROM recurring_tasks 
        WHERE is_active = 1
    ''')
    
    recurring_tasks = cursor.fetchall()
    
    for task in recurring_tasks:
        task_id, user_id, task_text, rec_type, task_time, days_of_week_json, day_of_month, last_generated = task
        
        should_generate = False
        
        if rec_type == 'daily':
            should_generate = last_generated != today.isoformat()
        elif rec_type == 'weekly':
            if days_of_week_json:
                days_of_week = json.loads(days_of_week_json)
                should_generate = today_weekday in days_of_week and last_generated != today.isoformat()
        elif rec_type == 'monthly':
            if day_of_month and today.day == day_of_month:
                should_generate = last_generated != today.isoformat()
        
        if should_generate:
            cursor.execute('''
                SELECT COUNT(*) FROM tasks 
                WHERE user_id = ? AND task_text = ? AND task_date = ?
            ''', (user_id, task_text, today.isoformat()))
            
            if cursor.fetchone()[0] == 0:
                cursor.execute('''
                    INSERT INTO tasks (user_id, task_text, task_date, task_time)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, task_text, today.isoformat(), task_time))
                
                cursor.execute('''
                    UPDATE recurring_tasks 
                    SET last_generated = ?
                    WHERE id = ?
                ''', (today.isoformat(), task_id))
    
    conn.commit()
    conn.close()

def main_menu_keyboard():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    buttons = [
        types.KeyboardButton("📅 Планы на сегодня"),
        types.KeyboardButton("🌅 Планы на завтра"),
        types.KeyboardButton("➕ Добавить задачу"),
        types.KeyboardButton("✅ Отметить выполненное"),
        types.KeyboardButton("🔄 Повторяющиеся задачи"),
        types.KeyboardButton("📊 Статистика"),
        types.KeyboardButton("🗓️ Загрузить расписание"),
        types.KeyboardButton("❓ Помощь")
    ]
    keyboard.add(*buttons)
    return keyboard

def get_tasks_keyboard(tasks, action_prefix):
    keyboard = types.InlineKeyboardMarkup()
    for task in tasks:
        task_id, task_text, task_time, is_completed, priority, category = task
        status_emoji = "✅" if is_completed else "⏳"
        time_str = f" ({task_time})" if task_time else ""
        
        callback_data = f"{action_prefix}_{task_id}"
        keyboard.add(types.InlineKeyboardButton(
            f"{status_emoji} {task_text[:40]}{time_str}",
            callback_data=callback_data
        ))
    
    keyboard.add(types.InlineKeyboardButton("🔙 Назад", callback_data="back_to_menu"))
    return keyboard

@bot.message_handler(commands=['start'])
def start_command(message):
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    
    add_user(user_id, username, first_name)
    user_states[user_id] = UserState.IDLE
    
    welcome_text = f"Привет, {first_name}! 👋\\n\\n" \\
                   f"Я твой личный планировщик задач! 📋\\n\\n" \\
                   f"🌟 **Что я умею:**\\n" \\
                   f"• 🌅 Присылаю планы каждое утро в 6:00\\n" \\
                   f"• ➕ Помогаю добавлять новые задачи\\n" \\
                   f"• 📅 Управляю расписанием на месяц и больше\\n" \\
                   f"• 🔄 Поддерживаю повторяющиеся задачи\\n" \\
                   f"• ✅ Отслеживаю выполнение\\n" \\
                   f"• 📊 Показываю статистику продуктивности\\n\\n" \\
                   f"Выбери нужную опцию в меню ниже! 👇"
    
    bot.send_message(message.chat.id, welcome_text, 
                    parse_mode="Markdown", 
                    reply_markup=main_menu_keyboard())

@bot.message_handler(func=lambda message: message.text == "📅 Планы на сегодня")
def today_tasks(message):
    show_tasks_for_date(message, datetime.now().date(), "сегодня")

@bot.message_handler(func=lambda message: message.text == "🌅 Планы на завтра")
def tomorrow_tasks(message):
    tomorrow = datetime.now().date() + timedelta(days=1)
    show_tasks_for_date(message, tomorrow, "завтра")

def show_tasks_for_date(message, date_obj, date_name):
    user_id = message.from_user.id
    date_str = date_obj.isoformat()
    tasks = get_daily_tasks(user_id, date_str)
    
    if not tasks:
        bot.send_message(message.chat.id, 
                        f"На {date_name} задач нет! 🎉\\n"
                        f"Можешь добавить новые через меню.")
        return
    
    response = f"📅 **Планы на {date_name} ({date_obj.strftime('%d.%m.%Y')}):**\\n\\n"
    
    for i, (task_id, task_text, task_time, is_completed, priority, category) in enumerate(tasks, 1):
        status = "✅" if is_completed else "⏳"
        time_str = f" в {task_time}" if task_time else ""
        priority_str = "🔥" if priority > 1 else ""
        
        response += f"{i}. {status} {priority_str}{task_text}{time_str}\\n"
    
    bot.send_message(message.chat.id, response, parse_mode="Markdown")

@bot.message_handler(func=lambda message: message.text == "➕ Добавить задачу")
def add_task_handler(message):
    user_id = message.from_user.id
    user_states[user_id] = UserState.ADDING_TASK
    
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add("📅 На сегодня", "🌅 На завтра")
    markup.add("📆 На конкретную дату", "📝 На эту неделю")
    markup.add("🔙 Назад")
    
    bot.send_message(message.chat.id, "Когда планируешь выполнить задачу?", reply_markup=markup)

@bot.message_handler(func=lambda message: message.text == "✅ Отметить выполненное")
def mark_completed_handler(message):
    user_id = message.from_user.id
    today = datetime.now().date().isoformat()
    tasks = get_daily_tasks(user_id, today)
    
    if not tasks:
        bot.send_message(message.chat.id, "На сегодня задач нет!")
        return
    
    keyboard = get_tasks_keyboard(tasks, "toggle")
    bot.send_message(message.chat.id, 
                    "Выбери задачу для отметки выполнения:", 
                    reply_markup=keyboard)

@bot.message_handler(func=lambda message: message.text == "📊 Статистика")
def show_statistics(message):
    user_id = message.from_user.id
    
    week_stats = get_user_stats(user_id, 7)
    month_stats = get_user_stats(user_id, 30)
    
    response = "📊 **Твоя статистика:**\\n\\n"
    response += f"📅 **За неделю:**\\n"
    response += f"• Всего задач: {week_stats['total']}\\n"
    response += f"• Выполнено: {week_stats['completed']}\\n"
    response += f"• Процент: {week_stats['percentage']:.1f}%\\n\\n"
    
    response += f"📆 **За месяц:**\\n"
    response += f"• Всего задач: {month_stats['total']}\\n"
    response += f"• Выполнено: {month_stats['completed']}\\n"
    response += f"• Процент: {month_stats['percentage']:.1f}%\\n\\n"
    
    if week_stats['percentage'] >= 80:
        response += "🎉 Отличная работа! Продолжай в том же духе!"
    elif week_stats['percentage'] >= 60:
        response += "👍 Хорошо! Есть к чему стремиться!"
    else:
        response += "💪 Не унывай! Каждый день - новая возможность!"
    
    bot.send_message(message.chat.id, response, parse_mode="Markdown")

@bot.message_handler(func=lambda message: message.text == "🗓️ Загрузить расписание")
def upload_schedule_handler(message):
    user_id = message.from_user.id
    user_states[user_id] = UserState.UPLOADING_SCHEDULE
    
    help_text = "📝 **Как загрузить расписание:**\\n\\n" \\
                "Отправь мне список задач в формате:\\n" \\
                "`дата задача время(необязательно)`\\n\\n" \\
                "**Примеры:**\\n" \\
                "• `01.11.2025 Встреча с врачом 14:30`\\n" \\
                "• `02.11 Купить продукты`\\n" \\
                "• `завтра Позвонить маме 19:00`\\n" \\
                "• `сегодня Сделать домашку`\\n\\n" \\
                "Можешь отправить сразу много задач - каждую с новой строки!"
    
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add("🔙 Отмена")
    
    bot.send_message(message.chat.id, help_text, 
                    parse_mode="Markdown", reply_markup=markup)

@bot.message_handler(func=lambda message: message.text == "❓ Помощь")
def help_handler(message):
    help_text = "🤖 **Справка по боту:**\\n\\n" \\
                "**Основные функции:**\\n" \\
                "• 📅 Планы на сегодня\\n" \\
                "• 🌅 Планы на завтра\\n" \\
                "• ➕ Добавить задачу\\n" \\
                "• ✅ Отметить выполненное\\n" \\
                "• 🔄 Повторяющиеся задачи\\n" \\
                "• 📊 Статистика\\n" \\
                "• 🗓️ Загрузить расписание\\n\\n" \\
                "**Особенности:**\\n" \\
                "• 🌅 Каждый день в 6:00 получаешь планы\\n" \\
                "• 🔒 Твои задачи видишь только ты\\n" \\
                "• 💾 Все данные сохраняются\\n" \\
                "• 🆓 Полностью бесплатно"
    
    bot.send_message(message.chat.id, help_text, parse_mode="Markdown")

@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    user_id = call.from_user.id
    
    if call.data.startswith("toggle_"):
        task_id = int(call.data.split("_")[1])
        new_status = toggle_task_completion(task_id, user_id)
        
        if new_status is not None:
            status_text = "выполненной" if new_status else "невыполненной"
            bot.answer_callback_query(call.id, f"Задача отмечена как {status_text}!")
            
            today = datetime.now().date().isoformat()
            tasks = get_daily_tasks(user_id, today)
            keyboard = get_tasks_keyboard(tasks, "toggle")
            
            bot.edit_message_reply_markup(call.message.chat.id, 
                                        call.message.message_id, 
                                        reply_markup=keyboard)

@bot.message_handler(func=lambda message: user_states.get(message.from_user.id) == UserState.UPLOADING_SCHEDULE)
def process_schedule_upload(message):
    user_id = message.from_user.id
    
    if message.text == "🔙 Отмена":
        user_states[user_id] = UserState.IDLE
        bot.send_message(message.chat.id, "Отменено.", reply_markup=main_menu_keyboard())
        return
    
    tasks_added = 0
    errors = []
    
    lines = message.text.strip().split('\\n')
    
    for line_num, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue
            
        try:
            parts = line.split(' ', 2)
            if len(parts) < 2:
                errors.append(f"Строка {line_num}: неверный формат")
                continue
            
            date_str = parts[0]
            remaining = ' '.join(parts[1:])
            
            task_date = None
            if date_str.lower() == 'сегодня':
                task_date = datetime.now().date()
            elif date_str.lower() == 'завтра':
                task_date = datetime.now().date() + timedelta(days=1)
            else:
                date_formats = ['%d.%m.%Y', '%d.%m', '%Y-%m-%d']
                for fmt in date_formats:
                    try:
                        if fmt == '%d.%m':
                            date_str_with_year = f"{date_str}.{datetime.now().year}"
                            task_date = datetime.strptime(date_str_with_year, '%d.%m.%Y').date()
                        else:
                            task_date = datetime.strptime(date_str, fmt).date()
                        break
                    except ValueError:
                        continue
            
            if not task_date:
                errors.append(f"Строка {line_num}: не удалось распознать дату")
                continue
            
            time_pattern = r'(\\d{1,2}[:.:]\\d{2})'
            time_match = re.search(time_pattern, remaining)
            task_time = None
            
            if time_match:
                time_str = time_match.group(1).replace('.', ':').replace(',', ':')
                try:
                    task_time = datetime.strptime(time_str, '%H:%M').time()
                    remaining = remaining.replace(time_match.group(1), '').strip()
                except ValueError:
                    pass
            
            task_text = remaining.strip()
            if not task_text:
                errors.append(f"Строка {line_num}: пустая задача")
                continue
            
            add_task(user_id, task_text, task_date.isoformat(), 
                    task_time.isoformat() if task_time else None)
            tasks_added += 1
            
        except Exception as e:
            errors.append(f"Строка {line_num}: ошибка")
    
    result_text = f"✅ **Результат:**\\n\\n• Добавлено задач: **{tasks_added}**\\n"
    
    if errors:
        result_text += f"• Ошибок: **{len(errors)}**"
    
    user_states[user_id] = UserState.IDLE
    bot.send_message(message.chat.id, result_text, 
                    parse_mode="Markdown", 
                    reply_markup=main_menu_keyboard())

@bot.message_handler(func=lambda message: user_states.get(message.from_user.id) == UserState.ADDING_TASK)
def process_task_addition(message):
    user_id = message.from_user.id
    
    if message.text == "🔙 Назад":
        user_states[user_id] = UserState.IDLE
        bot.send_message(message.chat.id, "Главное меню:", reply_markup=main_menu_keyboard())
        return
    
    task_date = None
    if message.text == "📅 На сегодня":
        task_date = datetime.now().date()
    elif message.text == "🌅 На завтра":
        task_date = datetime.now().date() + timedelta(days=1)
    
    if task_date:
        bot.send_message(message.chat.id, "📝 Опиши задачу:")
        bot.register_next_step_handler(message, lambda msg: save_simple_task(msg, task_date))

def save_simple_task(message, task_date):
    user_id = message.from_user.id
    task_text = message.text.strip()
    
    if not task_text:
        bot.send_message(message.chat.id, "Задача не может быть пустой!")
        return
    
    add_task(user_id, task_text, task_date.isoformat())
    
    user_states[user_id] = UserState.IDLE
    
    bot.send_message(message.chat.id, 
                    f"✅ **Задача добавлена!**\\n\\n"
                    f"📋 {task_text}\\n"
                    f"📅 {task_date.strftime('%d.%m.%Y')}",
                    parse_mode="Markdown",
                    reply_markup=main_menu_keyboard())

def send_morning_plans():
    generate_recurring_tasks()
    
    conn = sqlite3.connect('tasks.db', check_same_thread=False)
    cursor = conn.cursor()
    
    cursor.execute("SELECT user_id, first_name FROM users")
    users = cursor.fetchall()
    
    today = datetime.now().date().isoformat()
    
    for user_id, first_name in users:
        try:
            tasks = get_daily_tasks(user_id, today)
            
            if tasks:
                response = f"🌅 **Доброе утро, {first_name}!**\\n\\n"
                response += f"📅 **Планы на сегодня ({datetime.now().strftime('%d.%m.%Y')}):**\\n\\n"
                
                for i, (task_id, task_text, task_time, is_completed, priority, category) in enumerate(tasks, 1):
                    time_str = f" в {task_time}" if task_time else ""
                    priority_str = "🔥 " if priority > 1 else ""
                    response += f"{i}. {priority_str}{task_text}{time_str}\\n"
                
                response += "\\n💪 **Удачного дня!**"
                
                bot.send_message(user_id, response, parse_mode="Markdown")
            else:
                bot.send_message(user_id, 
                               f"🌅 **Доброе утро, {first_name}!**\\n\\n"
                               f"На сегодня задач нет! 🎉")
        except Exception as e:
            print(f"Ошибка отправки {user_id}: {e}")
            continue
    
    conn.close()

@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    user_id = message.from_user.id
    
    if user_id in user_states and user_states[user_id] != UserState.IDLE:
        user_states[user_id] = UserState.IDLE
    
    bot.send_message(message.chat.id, 
                    "Используй кнопки меню! 😊", 
                    reply_markup=main_menu_keyboard())

schedule.every().day.at("06:00").do(send_morning_plans)
schedule.every().hour.do(generate_recurring_tasks)

def run_schedule():
    while True:
        schedule.run_pending()
        time.sleep(60)

if __name__ == "__main__":
    print("🚀 Инициализация бота...")
    init_db()
    print("💾 База данных готова")
    
    schedule_thread = threading.Thread(target=run_schedule)
    schedule_thread.daemon = True
    schedule_thread.start()
    print("⏰ Планировщик запущен")
    
    print("✅ Бот готов!")
    print("🌅 Уведомления в 6:00")
    
    bot.infinity_polling(none_stop=True, interval=0, timeout=20)
"""

# Сохраняю как CSV для скачивания
with open('telegram_bot_complete.txt', 'w', encoding='utf-8') as f:
    f.write(bot_code)

print("✅ Создан файл: telegram_bot_complete.txt")
print("📥 Этот файл можно скачать!")
